<template>
    <Header />
    <Nav :isVisible="isNavVisible" />
    <Categories />

    <div v-if="product" class="flex justify-center items-center w-full">
        <div class="max-w-6xl min-h-screen py-10 px-4 ">
            <div
                class="max-w-6xl mx-auto grid md:grid-cols-2 gap-8 bg-gradient-to-b from-pink-100 to-white rounded-xl shadow-lg p-6">
                <!-- 商品圖片 -->
                <div class="relative w-full h-[400px] overflow-hidden  group" @mousemove="handleMouseMove"
                    @mouseleave="zoomVisible = false" ref="zoomBox">
                    <!-- 原圖 -->
                    <img :src="imageUrl" class="w-full h-full object-contain" />

                    <!-- 放大區域 -->
                    <div v-if="zoomVisible"
                        class="absolute w-48 h-48 border-2 border-pink-400 rounded-lg pointer-events-none z-50"
                        :style="lensStyle"></div>
                </div>


                <!-- 商品資訊 -->
                <div class="space-y-4">
                    <h2 class="text-3xl font-bold text-pink-600">{{ product.productName }}</h2>
                    <p class="text-xl text-gray-800 font-semibold">NT$ {{ product.price }}</p>

                    <!-- 庫存 -->
                    <p :class="product.stockQuantity > 0 ? 'text-green-600' : 'text-red-500'" class="text-sm">
                        庫存狀態：{{ product.stockQuantity > 0 ? '尚有庫存' : '已售完' }}
                    </p>

                    <!-- 顏色選擇
                    <div class="space-y-1">
                        <label class="text-sm font-medium text-gray-600">顏色</label>
                        <div class="flex gap-2">
                            <button v-for="(color, i) in product.colors" :key="i" @click="selectedColor = color" :class="[
                                'w-8 h-8 rounded-full border-2 transition',
                                selectedColor === color ? 'ring-2 ring-pink-400' : '',
                            ]" :style="{ backgroundColor: color }"></button>
                        </div>
                    </div> -->

                    <!-- 數量選擇 -->
                    <div class="flex items-center gap-3">
                        <label class="text-sm font-medium text-gray-600">數量</label>
                        <input type="number" v-model.number="quantity" min="1" :max="product.stock"
                            class="w-16 border rounded-md text-center focus:ring-2 focus:ring-pink-300" />
                    </div>

                    <!-- 操作按鈕 -->
                    <div class="flex gap-4 mt-4">
                        <button
                            class="flex-1 bg-pink-500 hover:bg-pink-600 text-white py-2 rounded-lg font-semibold transition"
                            @click="addToCart">
                            加入購物車
                        </button>
                        <button
                            class="flex-1 bg-purple-500 hover:bg-purple-600 text-white py-2 rounded-lg font-semibold transition"
                            @click="buyNow">
                            立即購買
                        </button>
                    </div>


                </div>
            </div>

            <!-- 推薦商品 -->
            <div class="max-w-6xl mx-auto mt-10">
                <h3 class="text-2xl font-bold text-pink-600 mb-2">推薦商品</h3>

                <Swiper :slides-per-view="1.5" :space-between="16" grab-cursor :breakpoints="{
                    640: { slidesPerView: 2.5 },
                    768: { slidesPerView: 3.5 },
                    1024: { slidesPerView: 4.5 }
                }" class="px-1">
                    <SwiperSlide v-for="item in recommended" :key="item.productId" class="!w-60">
                        <div
                            class="bg-white left-2 p-4 my-2 rounded-2xl shadow-md shadow-pink-100 border border-pink-200 hover:shadow-pink-300/60 hover:shadow-md transition duration-300 hover:scale-105 relative group">
                            <div
                                class="absolute inset-0 rounded-2xl bg-gradient-to-br from-pink-200 via-pink-100 to-violet-200 opacity-0 group-hover:opacity-100 transition duration-300 z-0 ring-1 ring-pink-300/50 group-hover:ring-4">
                            </div>


                            <div class="relative z-10">
                                <img :src="`http://localhost:7010/youbike/images/${item.productId}`" alt="推薦商品"
                                    class="rounded-xl h-36 w-full object-cover mb-3" />
                                <p class="text-sm font-semibold text-gray-700 truncate">
                                    {{ item.productName }}
                                </p>
                                <p class="text-pink-500 font-bold">NT$ {{ item.price }}</p>
                            </div>
                        </div>
                    </SwiperSlide>
                </Swiper>
            </div>

        </div>
    </div>
    <Rate />
    <Top />
    <supportChat />
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import Header from '@/components/HomePage/Header.vue';
import Nav from './Nav.vue';
import Rate from '@/components/ProductPage/Rate.vue';
import Top from '@/components/Top.vue';
import Categories from '@/components/Categories.vue';
import axios from 'axios';
import { useRoute } from 'vue-router';
import { useUserStore } from "@/stores/user.js";
import { useCartStore } from "@/stores/cart.js";
import { useToast } from 'vue-toastification';
import supportChat from '@/components/support-chat.vue';

import { Swiper, SwiperSlide } from 'swiper/vue'
import 'swiper/css'
import 'swiper/css/free-mode'
import SwiperCore from 'swiper'
SwiperCore.use([])


const toast = useToast()


const userStore = useUserStore();
const cartStore = useCartStore();


// 定義 product 為響應式資料
const product = ref(null);

// 拿路由參數（如 /products/3）
const router = useRoute();
const productId = router.params.id;

const recommended = ref([])

onMounted(async () => {
    try {
        const res = await axios.get(`http://localhost:7010/youbike/products/${productId}`);
        console.log(res);
        product.value = res.data;
    } catch (error) {
        console.error('載入商品詳情失敗', error);
    }
});

onMounted(async () => {
    try {
        const res = await axios.get(`http://localhost:7010/youbike/products/${productId}/recommendations`);
        recommended.value = res.data;
    } catch (error) {
        console.error('載入推薦商品失敗', error);
    }
});

onMounted(() => {
    const key = 'recentlyViewed'
    const viewed = JSON.parse(localStorage.getItem(key)) || []
    console.log([product]);

    const current = {
        productId: productId,
        productName: product.productName,
        price: product.price,
        image: product.imageIds?.[0] || 'no-image.jpg'
    }

    const filtered = viewed.filter(v => v.productId !== current.productId)
    const updated = [current, ...filtered].slice(0, 10)

    localStorage.setItem(key, JSON.stringify(updated))
})


// const product = {
//     name: '夢幻多彩棉花糖 T-Shirt',
//     price: 880,
//     image: '/image/dream1.png',
//     colors: ['#f87171', '#60a5fa', '#34d399'],
//     stock: 12
// }



// const selectedColor = ref(product.colors[0])
const quantity = ref(1)

async function addToCart() {

    const params = new URLSearchParams()
    params.append('productId', product.value.productId)
    params.append('quantity', quantity.value) // 注意這裡要加 .value
    // console.log(userStore.token);
    if (!userStore.token) {
        alert('請先登入會員')
        return
    }
    console.log("商品數量:" + product.value.stockQuantity);
    if (product.value.stockQuantity <= 0) {
        console.log("沒有了!!!");
        toast.error('商品已售罄')
        return
    }

    try {
        // console.log(token);
        const res = await axios.post(
            'http://localhost:7010/youbike/cart/add',
            params,
            {
                headers: {
                    Authorization: `Bearer ${userStore.token}`,
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        )


        cartStore.fetchCart()
        console.log(res.data)
        toast.success('加入購物車成功！')
        // alert(`已加入購物車：${product.value.productName} x${quantity.value}`)
    } catch (err) {
        console.error('加入購物車失敗：', err)
    }
}


const buyNow = () => {
    alert('跳轉到結帳流程...')
}

const isNavVisible = ref(false)

function handleScroll() {
    // 只要不在頂部就顯示
    isNavVisible.value = window.scrollY > 10
}

onMounted(() => {
    window.addEventListener('scroll', handleScroll)
})

onUnmounted(() => {
    window.removeEventListener('scroll', handleScroll)
})

const zoomBox = ref(null)
const zoomVisible = ref(false)
const lensStyle = ref({})
const imageUrl = `http://localhost:7010/youbike/images/${productId}`

function handleMouseMove(e) {
    const box = zoomBox.value.getBoundingClientRect()
    const x = e.clientX - box.left
    const y = e.clientY - box.top
    zoomVisible.value = true

    const lensSize = 192
    const zoomScale = 2

    // 限制邊界
    const posX = Math.max(0, Math.min(x, box.width))
    const posY = Math.max(0, Math.min(y, box.height))

    lensStyle.value = {
        left: `${posX - lensSize / 2}px`,
        top: `${posY - lensSize / 2}px`,
        backgroundImage: `url(${imageUrl})`,
        backgroundSize: `${box.width * zoomScale}px ${box.height * zoomScale}px`,
        backgroundRepeat: 'no-repeat',
        backgroundPosition: `-${(posX * zoomScale) - lensSize / 2}px -${(posY * zoomScale) - lensSize / 2}px`,
    }
}

</script>

<style scoped></style>
