<template>
    <div
        class="relative mt-2 mb-2 p-[2px] rounded-xl bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-300 shadow-md hover:shadow-lg transition-transform transform hover:scale-105">
        <div class="bg-white h-full w-auto">



        </div>
    </div>

</template>

<script setup>

</script>
