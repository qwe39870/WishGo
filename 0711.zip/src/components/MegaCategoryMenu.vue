<template>
  <div class="relative">
    <!-- ✅ 浮在上面的分類區 -->
    <div
      class="absolute top-12 left-[18.5%] w-[150px] z-10"
      @mouseleave="() => { isHoveringMenu = false; handleMouseLeave() }"
    >
      <!-- 主分類 -->
      <ul class="w-full bg-purple-400 divide-y divide-purple-800 border border-purple-800 rounded-md shadow">
        <li
          v-for="category in categories"
          :key="category.id"
          @mouseenter="() => { hoveredCategoryId = category.id; isHoveringMenu = true }"
          class="px-4 py-3 text-white cursor-pointer hover:bg-purple-800 transition"
          :class="{ 'bg-pink-100 font-bold': hoveredCategoryId === category.id }"
        >
          {{ category.name }}
        </li>
      </ul>

      <!-- 子分類浮出 -->
      <div
        v-if="hoveredCategoryId"
        class="absolute left-full top-0 w-[600px] min-h-full bg-white border border-l-pink-100 p-6 z-50 shadow-lg"
        @mouseenter="isHoveringMenu = true"
        @mouseleave="() => { isHoveringMenu = false; handleMouseLeave() }"
      >
        <p class="text-pink-500 font-bold mb-4">子分類</p>
        <div class="grid grid-cols-3 gap-4">
          <div
            v-for="sub in currentSubcategories"
            :key="sub.id"
            class="text-center"
          >
            <img :src="sub.image" class="w-20 h-20 object-cover rounded-md shadow mb-2 mx-auto" />
            <p class="text-sm text-gray-700">{{ sub.name }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- ✅ 底下正常頁面內容 -->
    
  </div>
</template>


<script setup>
import { ref, computed } from 'vue'

const hoveredCategoryId = ref(null)
const isHoveringMenu = ref(false)

const handleMouseLeave = () => {
  setTimeout(() => {
    if (!isHoveringMenu.value) hoveredCategoryId.value = null
  }, 100)
}

const categories = [
  { id: 1, name: '美妝保養' },
  { id: 2, name: '電子產品' },
  { id: 3, name: '時尚配件' },
  { id: 4, name: '文具用品' },
  { id: 5, name: '家居裝飾' }
]

const subcategories = [
  { id: 101, categoryId: 1, name: '口紅', image: 'https://placekitten.com/80/80' },
  { id: 102, categoryId: 1, name: '護手霜', image: 'https://placekitten.com/81/81' },
  { id: 201, categoryId: 2, name: '耳環', image: 'https://placekitten.com/82/82' },
  { id: 202, categoryId: 2, name: '髮夾', image: 'https://placekitten.com/83/83' }
]

const currentSubcategories = computed(() =>
  subcategories.filter(sub => sub.categoryId === hoveredCategoryId.value)
)
</script>
